// definitions for the hardware

const int RED_LED = 32;
const int GREEN_LED = 33;

const int BUTTON1 = 0;
const int BUTTON2 = 34;
const int BUTTON3 = 39;
const int BUTTON4 = 36;

const int R = 18;
const int G = 5;
const int B = 19;

const String sVersion = "3.02";
