/**************************************************

**************************************************/
String sReturnTEMP() {
  char tmp[10];
  memset(tmp, 0x00, sizeof(tmp));
  snprintf(tmp, sizeof(tmp), "%04X", tempC);
  return (String)tmp;
}

/**************************************************

**************************************************/
String sReturnUpTime() {
  char tmp[10];
  memset(tmp, 0x00, sizeof(tmp));
  snprintf(tmp, sizeof(tmp), "%08X", ulUpTime);
  return (String)tmp;
}

/**************************************************

**************************************************/
//String sSensors() {
//  return (sReturnLight());
//}

/**************************************************

**************************************************/
void prepareJSONStrings() {

  char cTemp[20];

  stempC = (String)tempC;
#ifdef DEBUG
  Serial.print("DS18B20 Temp = "); Serial.println(tempC);
  Serial.println("-------------------------------------------------------");
#endif
}

void ReadValues() {
#ifdef ESP32_DEBUG
  Serial.println("ReadValues->Entry");
#endif

#ifdef ESP32_DEBUG
  Serial.println("ReadValues->Exit");
#endif
}
