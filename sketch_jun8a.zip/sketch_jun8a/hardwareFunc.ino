unsigned long lastDebounceTime = 0;  // the last time the output pin was toggled
unsigned long debounceDelay = 50;    // the debounce time; increase if the output flickers

bool bLock = false;

long buttonPressedStart;
long buttonPressedCurrentTime;

/**************************************************

**************************************************/
void checkButton(BUTTON *b) {
  // read the state of the switch into a local variable:
  int reading = digitalRead(b->buttonIO);

  // check to see if you just pressed the button
  // (i.e. the input went from HIGH to LOW), and you've waited long enough
  // since the last press to ignore any noise:

  // If the switch changed, due to noise or pressing:
  if (reading != b->lastButtonState) {
    // reset the debouncing timer
    lastDebounceTime = millis();
  }

  if ((millis() - lastDebounceTime) > debounceDelay) {
    // if the button state has changed:
    if (reading != b->buttonState) {
      b->buttonState = reading;

      // only toggle the LED if the new button state is LOW
      if (b->buttonState == LOW) {
        b->outputState = !b->outputState;
        Serial.print("button: "); Serial.print (b->sName);
        Serial.print(" / outputState: "); Serial.println (b->outputState);

        if (dsplayUpdFlag == 0) {
          dsplayUpdFlag = 1;
          OLEDSetup();
          displayData();
          displayTimeCount = 0;
          return;
        }
        displayTimeCount = 0;


        b->processOut = 1;
        buttonPressedStart = millis();
      }
    }
  }

  if (b->buttonState == LOW)
  {
    buttonPressedCurrentTime = millis();
    if ((buttonPressedCurrentTime - buttonPressedStart) > 2000)
    {
      //Serial.println(buttonPressedStart);
      //Serial.println(buttonPressedCurrentTime);
      //Serial.println(b->sName);
      b->longPressed = 1;
    }
  }
  else
  {
    b->longPressed = 0;
  }

  // set the LED:
  //  digitalWrite(ledPin, ledState);

  // save the reading. Next time through the loop, it'll be the lastButtonState:
  b->lastButtonState = reading;
}

/**************************************************

**************************************************/
void checkButtons() {
  checkButton(&BTN1);
  checkButton(&BTN2);
  checkButton(&BTN3);
  checkButton(&BTN4);
  processOutput(&BTN1);
  processOutput(&BTN2);
  processOutput(&BTN3);
  processOutput(&BTN4);

  //processLongPress(&BTN3);
}

/**************************************************

**************************************************/
void processOutput(BUTTON *b) {
  char t[2000];
  while (bLock == true) {}
  if (b->processOut == 1) {
    b->processOut = 0;

    if (ucSettings == 1) {
      if (ucMenuState == 0)
      {
        if (b->buttonNumber == 2) {
          ucMenuState = 1;
          return;
        }

      }
      if (ucMenuState == 1)
      {
        if (b->buttonNumber == 2) {
          ucMenuState = 2;
          return;
        }
      }

      if (ucMenuState == 2)
      {
        if (b->buttonNumber == 2) {
          ucMenuState = 3;
          return;
        }
      }

      if (ucMenuState == 3)
      {
        if (b->buttonNumber == 2) {
          ucMenuState = 4;
          return;
        }
      }
    }
  }
}


void IRAM_ATTR resetModule() {
  ets_printf("reboot\n");
  //  esp_restart_noos();
  esp_restart();
}

void resetModule1() {
  ets_printf("reboot\n");
  //  esp_restart_noos();
  esp_restart();
}
