
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels

#define OLED_RESET     -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define SCREEN_ADDRESS 0x3C ///< See datasheet for Address; 0x3D for 128x64, 0x3C for 128x32
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);



/**************************************************

**************************************************/
void OLEDSetup() {
  // Start the I2C interface
  Wire.begin();

  // SSD1306_SWITCHCAPVCC = generate display voltage from 3.3V internally
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed"));
    for(;;); // Don't proceed, loop forever
  }
  // init done
  // Clear the buffer.
  display.clearDisplay();

  // text display tests
  display.setCursor(15, 0);
  display.setTextSize(2);
  display.setTextColor(WHITE, BLACK);
  display.println("ESP32 UC");
  display.display();
}


/**************************************************

**************************************************/
void displayUseWiFi(unsigned char ucUseWiFi) {
  if (dsplayUpdFlag == 1) {
    String tmp = "Use WiFi: " + (String)ucUseWiFi;
    displayTEXT(0, 30, tmp, false);
    displayTEXT(0, 40, "                     ", true);
    //displayTEXT(3, 30, "test-test-test", true);
  }
}



/**************************************************

**************************************************/
void displayTEXT(unsigned char x, unsigned char y, String sTxt, bool bUpdate) {
  if (dsplayUpdFlag == 1) {
    display.setCursor(x, y);
    display.setTextSize(1);
    display.setTextColor(WHITE, BLACK);

    display.print(sTxt);
    if (bUpdate) display.display();
  }
}

/**************************************************

**************************************************/
void displayData() {
#ifdef DEBUG
  Serial.println("displayData->Entry");
  Serial.print("displaySettings = ");
  Serial.println(displaySettings);
#endif
  //  if (dsplayUpdFlag == 1) {
  //    if (displaySettings == 0) {
//  UpdateTimers();
//  displayEmptyStr(40);
//  UpdateTimers();
//  displayEmptyStr(50);  //50

  UpdateTimers();
  displayTMP();  //20
  UpdateTimers();
  
  UpdateTimers();
  displayEmptyStr(50);  //50
//    }
//  }
#ifdef DEBUG
  Serial.println("displayData->Exit");
#endif
}

/**************************************************

**************************************************/
void displayVersion() {
  String tmp = "Version: " + (String)sVersion + "        ";
  if (dsplayUpdFlag == 1) {
    displayTEXT(0, 20, tmp, false);
  }
}

/**************************************************

**************************************************/
void displayUptime() {
  String tmp = Suptime(ulUpTime);
  if (dsplayUpdFlag == 1) {
    displayTEXT(0, 30, tmp, false);
  }
}

/**************************************************

**************************************************/
void displayEmptyStr(unsigned char pos) {
  String tmp = "                    ";
  if (dsplayUpdFlag == 1) {
    displayTEXT(0, pos, tmp, true);
  }
}

/**************************************************

**************************************************/
void displayTMP() {
  String tmp = "TMP:  " + (String)tempC + "          ";
  if (dsplayUpdFlag == 1) {
    displayTEXT(0, 20, tmp, false);
  }
}


/**************************************************

**************************************************/
void displayWiFi() {
  String tmp = "WiFi: " + (String)WiFi.SSID() + "           ";
  if (dsplayUpdFlag == 1) {
    displayTEXT(0, 20, tmp, false);
  }
}

/**************************************************

**************************************************/
void displayMAC() {
  String tmp = "MAC: " + wifiMacString + "           ";
  if (dsplayUpdFlag == 1) {
    displayTEXT(0, 40, tmp, false);
  }
}

/**************************************************

**************************************************/
void displayIP() {
  String tmp = "IP: " + (String)ipToString(WiFi.localIP()) + "           ";
  if (dsplayUpdFlag == 1) {
    displayTEXT(0, 50, tmp, true);
  }
}



void testdrawrect(void) {
  for (int16_t i = 0; i < display.height() / 2; i += 2) {
    display.drawRect(i, i, display.width() - 2 * i, display.height() - 2 * i, WHITE);
    display.display();
    delay(1);
  }
}

void clearDisplay() {
  display.clearDisplay();
  display.display();
}

/**************************************************

**************************************************/
void displayMinuteInterval(unsigned char ucInterval) {
  if (dsplayUpdFlag == 1) {
    String tmp = "Select interval: " + (String)ucInterval + " m ";
    displayTEXT(0, 30, tmp, false);
    displayTEXT(0, 40, "                     ", true);
    //displayTEXT(3, 30, "test-test-test", true);
  }
}

///**************************************************
//
//**************************************************/
//void displayUseWiFi(unsigned char ucUseWiFi) {
//  if (dsplayUpdFlag == 1) {
//    String tmp = "Use WiFi: " + (String)ucUseWiFi;
//    displayTEXT(0, 30, tmp, false);
//    displayTEXT(0, 40, "                     ", true);
//    //displayTEXT(3, 30, "test-test-test", true);
//  }
//}
//
///**************************************************
//
//**************************************************/
//void displaySplashScreen() {
//  if (dsplayUpdFlag == 1) {
//    displayTEXT(0, 20, "Sensor calibration:", false);
//    displayTEXT(0, 30, "Buttons B4 + B5", false);
//    displayTEXT(0, 40, "User settings:", false);
//    displayTEXT(0, 50, "Buttons B4", true);
//  }
//}

/**************************************************

**************************************************/
void clearSplashScreen() {
  if (dsplayUpdFlag == 1) {
    displayTEXT(0, 20, "                   ", false);
    displayTEXT(0, 30, "               ", false);
    displayTEXT(0, 40, "              ", false);
    displayTEXT(0, 50, "          ", true);
  }
}

/**************************************************

**************************************************/
void displayClrFlag() {
  if ((displayTimeCount >= 12) && (dsplayUpdFlag == 1)) {
#ifdef ESP32_DEBUG
    Serial.println("Turning off display");
#endif
    dsplayUpdFlag = 0;
    display.clearDisplay();
    display.display();
  }
}
