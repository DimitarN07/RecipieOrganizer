#include <time.h>
#include <sys/time.h>

/**************************************************

**************************************************/
int find_textEX(String needle, String haystack) {
  int foundpos = -1;
  for (int i = 0; (i < haystack.length() - needle.length()); i++) {
    if (haystack.substring(i, needle.length() + i) == needle) {
      foundpos = i;
    }
  }
  return foundpos;
}

/**************************************************

**************************************************/
void setESPTime() {
  const long gmtOffset_sec = 7200;
  const int daylightOffset_sec = 0;
  configTime(gmtOffset_sec, daylightOffset_sec, "pool.ntp.org", "time.nist.gov");
  //configTime(0, 0, "pool.ntp.org", "time.nist.gov");

  Serial.print(F("Waiting for NTP time sync "));
  time_t nowSecs = time(nullptr);
  while (nowSecs < 8 * 3600 * 2) {
    delay(500);
    Serial.print(F("."));
    yield();
    nowSecs = time(nullptr);
  }
  struct tm timeinfo;
  gmtime_r(&nowSecs, &timeinfo);

  Serial.println("");
  Serial.println(F("Got NTP time"));
}

void getESPTime(char * ret) {

  Serial.println("Returning time");

  struct tm now;
  getLocalTime(&now, 0);
  //Serial.println(&now, " %B %d %Y %H:%M:%S (%A)");

  char s[100];
  int rc;

  rc = strftime(s, sizeof(s), "D:%D, T:%T", &now);
  Serial.println(s);
  strcpy(ret, s);
}

/**************************************************

**************************************************/
void retString(char * string, unsigned char size, unsigned char * buffer, byte bufSize)
{
  char t[5];
  memset(string, 0x00, size);
  for (int i = 0; i < bufSize; i++) {
    snprintf(t, sizeof(t), "%02x", buffer[i]);
    strcat(string, t);
  }
}

/**************************************************

**************************************************/
unsigned char genCRC8(unsigned char *data, unsigned int len) {
  unsigned char crc = 0x00;
  while (len--) {
    unsigned char extract = *data++;
    for (int tempI = 8; tempI; tempI--) {
      unsigned char sum = (crc ^ extract) & 0x01;
      crc >>= 1;
      if (sum) {
        crc ^= 0x8C;
      }
      extract >>= 1;
    }
  }
  return crc;
}


/**************************************************

**************************************************/
unsigned char chechSumXOR(unsigned char *data, unsigned int len) {
  unsigned char xorCS = 0x00;
  for (int i = 0; i < len; i++) {
    unsigned char extract = *data++;
    xorCS ^= extract;

  }
  return xorCS;
}

/**************************************************

**************************************************/
String getMac() {
  char esp32MQTTClient[30];
  unsigned char mac[6];

  memset(esp32MQTTClient, 0x00, sizeof(esp32MQTTClient));

  WiFi.macAddress(mac);

  snprintf(esp32MQTTClient, sizeof(esp32MQTTClient), "%02X%02X%02X%02X%02X%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5], mac[6]);
  return (String)esp32MQTTClient;
}

/**************************************************

**************************************************/
String Suptime(unsigned long secs)
{
  static char _return[32];
  unsigned long mins=secs/60;
  unsigned int hours=mins/60, days=hours/24;
  memset(_return,0x00,sizeof(_return));
  secs-=mins*60;
  mins-=hours*60;
  hours-=days*24;
  sprintf(_return,"Uptime: %03dd %02dh %02dm", (byte)days, (byte)hours, (byte)mins);
  return (String)_return;
}

/**************************************************

**************************************************/
String ipToString(IPAddress ip){
  String s="";
  for (int i=0; i<4; i++)
    s += i  ? "." + String(ip[i]) : String(ip[i]);
  return s;
}
