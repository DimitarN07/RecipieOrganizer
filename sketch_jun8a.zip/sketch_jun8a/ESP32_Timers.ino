#define MS_IN_MINUTE 60000

/**************************************************

**************************************************/
void SetupTimers(void) {
  secondsTickTmr.every(1000, secondsTick1Sec);
  secondsTickTmr10Seconds.every(10000, measureUpdateData);
  SQLInsertTemperature.every(30000, SQLInsertTemp);
}

/**************************************************

**************************************************/
void UpdateTimers(void) {
//  tmr.update();
  secondsTickTmr.update();
  secondsTickTmr10Seconds.update();
  SQLInsertTemperature.update();

}

/**************************************************

**************************************************/
void secondsTick1Sec() {
  ulUpTime = ulUpTime + 1;
  lastUpdate += 1;
  digitalWrite(GREEN_LED, !digitalRead(GREEN_LED));
}

void measureUpdateData(void)
{
  ReadValues();
//  displayData();
}


void SQLInsertTemp(){


}